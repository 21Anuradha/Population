package com.anuradha;

import com.anuradha.model.Individuals;
import com.anuradha.repository.IndividualsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class FastTimeScheduler {
    @Autowired
    private IndividualsRepository individualsRepository;

    @Scheduled(cron = "0 */1 * * * *") // run in every one minute automatically to increase the age by +1, because we are treating 1 min as 1 year
    public void fastForwardTimeScheduler() {

        List<Individuals> allData = individualsRepository.findAllData(); // here we retrieve whole data

        // now we will iterate over this allData and increase the age of all member with other conditions as well
        for(Individuals individual:allData){

            // Increment the age by one if the person is not dead and or he/she is  over 80 age
            if(individual.getAge()<80&&individual.getIsAlive()) {
                int currentAge = individual.getAge();
                individual.setAge(currentAge + 1);
            }

            // now if a individual is of 30 year old and is alive , a new baby will born
            if(individual.getAge()==30&&individual.getIsAlive()){
                Individuals newIndividual= new Individuals();// we have created a new individual a set it all new value
                newIndividual.setName(individual.getName()+"'s ward");
                newIndividual.setAge(0);
                newIndividual.setAlive(true);
                newIndividual.setFamily(individual.getFamily());
                newIndividual.setBirthDate(new Date());
                newIndividual.setDeathDate(null);
                individualsRepository.save(newIndividual); // we have saved it to the database via repository
            }
            if(individual.getAge()==80){
                individual.setAlive(false);
                individual.setDeathDate(new Date());
            }
            // we have saved the changes in the database of old individuals --> main change is the, increment in the age
            individualsRepository.save(individual);
        }

    }

}
