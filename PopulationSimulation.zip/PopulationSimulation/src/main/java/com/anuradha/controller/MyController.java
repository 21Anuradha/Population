package com.anuradha.controller;

import com.anuradha.model.Individuals;
import com.anuradha.repository.IndividualsRepository;
import com.anuradha.service.BussinessLogic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {

    @Autowired
    private BussinessLogic bussinessLogic;

    // 1. to get current population of the village.
    @GetMapping("/get/current-population/count")
    public Long getCurrentPopulationOfVillage(){

        return bussinessLogic.findCurrentPopulationOfVillage();
    }

    // 2. to get count of death.
    @GetMapping("/get/death/count")
    public Long getcountOfDeadPopulationOfVillage(){

        return bussinessLogic.findDeadPopulationOfVillage();
    }
    // 3. to get count of newBorn.
    @GetMapping("/get/count/new-born")
    public Long getCountOfNewBorn(){
       return bussinessLogic.getCountOfNewBorn();
    }

    // 4. api to get all information of currently living bodies.
    @GetMapping("/get/all/info/of/living-population")
    public List<Individuals> getAllDataOfIndividulas(){

        return bussinessLogic.findAllDataOfIndividuals();

    }
    // 5. additional api for accidental death of a person. // we have changed the status manually in the database of accidental death
    @GetMapping("/api/count/of/accidental-death")
    public Long getCountOfAccidentalDeath(){
        return bussinessLogic.getCountOfAccidentalDeath();
    }

    // 6. additional Post api for accidental death of a person. In this we set the isAlive status by api

    @PutMapping("/api/accidental-death/status/change")
    public Object changeTheStatusInCaseOfAccidentalDeath(@RequestParam Long id){

        return bussinessLogic.changeTheStatusInCaseOfAccidentalDeath(id);

    }



    @PostMapping("/add/data/in/individual")
    public Individuals addDataInIndividuals(@RequestBody Individuals individuals){

        Individuals newIndividuals = bussinessLogic.addDataInIndividuals(individuals);
        return newIndividuals;
        /*
        Dummy data for adding data in individuals
        {
          "name": "John Doe",
          "age": 30,
          "family": {
            "familyId": 1
          },
          "isAlive": true,
          "birthDate": "1992-05-15",
          "deathDate": null
        }


         */
    }
}
