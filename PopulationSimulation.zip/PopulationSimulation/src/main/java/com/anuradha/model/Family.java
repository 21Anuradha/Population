package com.anuradha.model;

import jakarta.persistence.*;

@Entity
@Table(name = "family")
public class Family {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "family_id")
    private Long familyId;

    @Column(name = "family_name", nullable = false, length = 255)
    private String familyName;

    @ManyToOne
    @JoinColumn(name = "village_id")
    private Village village;

    /**
     * The @ManyToOne annotation in the Family class denotes a many-to-one relationship between the Family entity and the Village entity.
     *
     * In the provided code snippet, the Family class has a field named village of type Village. This field represents the association between a family and a village.
     *
     * The @ManyToOne annotation indicates that multiple Family entities can be associated with a single Village entity. In other words, multiple families can belong to the same village.
     *
     * The @JoinColumn(name = "village_id") annotation specifies the foreign key column in the family table that references the primary key column (id) of the village table.
     *
     * By using @ManyToOne and @JoinColumn, you establish a many-to-one relationship between the Family and Village entities, where many families can be associated with a single village.
     */

    // Constructors, getters, and setters

    public Family() {
    }

    public Family(String familyName, Village village) {
        this.familyName = familyName;
        this.village = village;
    }

    // Getters and setters for familyId, familyName, and village

    public Long getFamilyId() {
        return familyId;
    }

    public void setFamilyId(Long familyId) {
        this.familyId = familyId;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public Village getVillage() {
        return village;
    }

    public void setVillage(Village village) {
        this.village = village;
    }
}

