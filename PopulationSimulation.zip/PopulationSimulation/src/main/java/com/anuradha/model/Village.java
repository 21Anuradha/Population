package com.anuradha.model;

import jakarta.persistence.*;


@Entity
@Table(name = "village")
public class Village {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "village_name", nullable = false, length = 255)
    private String villageName;

    // Constructors, getters, and setters

    public Village() {
    }

    public Village(String villageName) {
        this.villageName = villageName;
    }

    // Getters and setters for id and villageName

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }
}
