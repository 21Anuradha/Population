package com.anuradha.repository;

import com.anuradha.model.Individuals;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IndividualsRepository extends JpaRepository<Individuals, Long> {
    @Query(value = "select * from individuals where is_alive=true",nativeQuery = true)
    List<Individuals> findAllData();

    @Query(value = "SELECT count(*) FROM individuals where is_alive=true",nativeQuery = true)
    Long findCurrentPopulation();

    @Query(value = "SELECT count(*) FROM individuals where is_alive=false",nativeQuery = true)
    Long findDeadPopulation();

    @Query(value = "SELECT count(*) FROM individuals where age<1",nativeQuery = true)
    Long findCountOfNewBorn();

    @Query(value = "SELECT count(*) FROM individuals where age<80 and is_alive=false",nativeQuery = true)
    Long findCountOfAccidentalDeath();
    @Query(value = "SELECT * FROM anuradha.individuals where id=?1",nativeQuery = true)
    Individuals findByIdOfIndividual(Long id);
}
