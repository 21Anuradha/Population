package com.anuradha.service;

import com.anuradha.model.Individuals;
import com.anuradha.repository.IndividualsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.crypto.Data;
import java.util.Date;
import java.util.List;

@Service
public class BussinessLogic {


    @Autowired
    private IndividualsRepository individualsRepository;

    public List<Individuals> findAllDataOfIndividuals() {

        List<Individuals> allData = individualsRepository.findAllData();
        return allData;
    }

    public Long findCurrentPopulationOfVillage() {
        return individualsRepository.findCurrentPopulation();
    }

    public Long findDeadPopulationOfVillage() {
        return individualsRepository.findDeadPopulation();

    }

    public Individuals addDataInIndividuals(Individuals individuals) {
        Individuals save = individualsRepository.save(individuals);
        return save;
    }

    public Long getCountOfNewBorn() {
        return individualsRepository.findCountOfNewBorn();
    }

    public Long getCountOfAccidentalDeath() {
        return individualsRepository.findCountOfAccidentalDeath();
    }

    public Object changeTheStatusInCaseOfAccidentalDeath(Long id) {

        Individuals individuals= individualsRepository.findByIdOfIndividual(id);
        individuals.setAlive(false);
        individuals.setDeathDate(new Date());
        Individuals save = individualsRepository.save(individuals);
        return save;
    }
}
