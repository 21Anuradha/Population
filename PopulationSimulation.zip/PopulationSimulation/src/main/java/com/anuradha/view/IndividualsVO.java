package com.anuradha.view;

public class IndividualsVO {
}
